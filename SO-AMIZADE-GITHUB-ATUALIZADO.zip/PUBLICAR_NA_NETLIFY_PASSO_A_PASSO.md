# SÓ AMIZADE — publicação correta na Netlify

> Antes de publicar, consulte também `LEIA-PRIMEIRO-DEPLOY.md`: ele reúne os passos da Netlify e a correção do domínio autorizado no Firebase.

## O erro que precisa ser corrigido

A mensagem de indisponibilidade da validação aparece quando o deploy publicado contém somente os arquivos estáticos de `dist/`. A função de servidor não fica dentro de `dist`: ela está em `netlify/functions/verify-age.mjs` e precisa ser enviada no mesmo deploy.

**Não publique apenas `dist/` e não envie o ZIP como se ele fosse o site.** Publique o projeto completo a partir da raiz, por integração Git ou Netlify CLI.

## Conferência da estrutura

Na raiz do repositório/pasta do projeto devem estar juntos:

- `package.json`
- `netlify.toml`
- `netlify/functions/verify-age.mjs`
- `src/`
- `public/`

Não coloque tudo dentro de uma segunda pasta chamada `so-amizade`, deixando `package.json` escondido um nível abaixo.

## Opção 1 — GitHub + Netlify (publicação automática)

1. Extraia este ZIP.
2. Envie **todo o conteúdo da pasta extraída** para a raiz de um repositório GitHub. Não envie somente `dist/`.
3. Na Netlify, abra **Add new project → Import an existing project → GitHub**.
4. Autorize o GitHub, selecione o repositório e deixe o diretório-base vazio (raiz).
5. Confira as configurações: **Build command:** `npm run build`; **Publish directory:** `dist`.
6. Publique o projeto. O `netlify.toml` já indica a pasta das funções: `netlify/functions`.

Se já existe um site na Netlify e você precisa manter exatamente o mesmo endereço, conecte o repositório ao projeto existente nas configurações de implantação contínua, em vez de criar outro projeto.

## Opção 2 — Netlify CLI (sem GitHub)

Execute os comandos na raiz do projeto, em um computador ou terminal com Node.js instalado:

```bash
npm install
npx netlify login
npx netlify link
npx netlify deploy --prod
```

No comando `netlify link`, selecione o site existente. O `netlify deploy --prod` lê o `netlify.toml`, executa o build e envia os arquivos estáticos e as funções. Não use `--no-build` nesta primeira publicação.

## Como confirmar que a correção entrou no ar

Depois do deploy, abra no navegador:

`https://SEU-DOMINIO.netlify.app/.netlify/functions/verify-age`

A resposta esperada é HTTP 200 com JSON semelhante a:

```json
{"ok":true,"service":"SÓ AMIZADE age verification"}
```

Depois teste o cadastro com uma data de nascimento válida de adulto. A validação do servidor precisa responder; não remova nem contorne a regra de 18 anos para esconder o problema.

## O que já está configurado neste projeto

- `netlify.toml` define `npm run build`, publicação de `dist`, Node 22 e `netlify/functions`.
- A rota `/.netlify/functions/verify-age` está implementada.
- A rota amigável `/api/verify-age` redireciona para a função.
- A função valida formato, existência da data e idade mínima de 18 anos.

O código não consegue publicar a própria função na conta Netlify sem que um deploy por Git ou CLI seja executado. O último passo depende de autenticação na sua conta Netlify/GitHub.
