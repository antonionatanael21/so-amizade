# Publicar o SÓ AMIZADE na Netlify pelo celular

## Por que apareceu o erro de validação?

O deploy que está no ar foi publicado apenas com o conteúdo de `dist/`. Isso coloca a interface no ar, mas **não publica funções serverless**. O projeto já contém a função `netlify/functions/verify-age.mjs` e a configuração `netlify.toml`; os dois precisam estar no repositório usado pela Netlify.

## 1. Extraia o ZIP

No Android, abra o app Arquivos/Files, localize o ZIP desta entrega e escolha **Extrair**. Na pasta extraída devem aparecer juntos:

- `package.json`
- `netlify.toml`
- `netlify/`
- `src/`
- `public/`

Dentro de `netlify/` deve existir `functions/verify-age.mjs`.

**Não envie somente a pasta `dist/`. Não envie o ZIP como único arquivo do repositório.**

## 2. Envie o projeto completo ao GitHub

1. Entre em https://github.com e faça login.
2. Crie um repositório novo chamado `so-amizade` (pode ser privado).
3. Abra o repositório e use **Add file → Upload files**.
4. Envie o conteúdo da pasta extraída, mantendo a estrutura de pastas. Os arquivos `package.json` e `netlify.toml` devem ficar na raiz do repositório, e não dentro de uma pasta extra chamada `so-amizade-corrigido/`.
5. Confirme em **Commit changes**.

Se o GitHub pelo navegador do celular não permitir selecionar pastas inteiras, faça o envio pelo app/site que suporte upload de múltiplos arquivos preservando a estrutura, ou use um computador. Não crie um repositório contendo apenas o arquivo ZIP.

## 3. Conecte o repositório à Netlify

1. Entre em https://app.netlify.com.
2. Escolha **Add new project → Import an existing project → GitHub**.
3. Autorize a Netlify a acessar o repositório `so-amizade` e selecione-o.
4. Deixe **Base directory / Root directory** em branco (raiz do repositório).
5. Use estas configurações, caso a Netlify não as detecte automaticamente:
   - Build command: `npm run build`
   - Publish directory: `dist`
6. Inicie o deploy.

O arquivo `netlify.toml` já configura `netlify/functions` como diretório das funções e a rota `/api/verify-age`. A Netlify precisa fazer o build a partir da raiz do repositório para detectar e publicar a função junto com o site.

## 4. Confirme que a função foi publicada

Abra no navegador, substituindo pelo domínio verdadeiro do seu site:

`https://SEU-SITE.netlify.app/.netlify/functions/verify-age`

A resposta esperada é JSON com `ok: true`, por exemplo:

`{"ok":true,"service":"SÓ AMIZADE age verification"}`

Se aparecer 404, abra a página do deploy na Netlify e confira os detalhes de **Functions**. A função `verify-age` precisa aparecer na lista. Também confirme que `netlify/functions/verify-age.mjs` está no GitHub, exatamente nesse caminho.

Depois, teste novamente o cadastro com sua data de nascimento. A rota `/api/verify-age` também deve encaminhar para a função.

## Observação

Este procedimento publica o código e a função. Ele não configura automaticamente provedores do Firebase/Google, não publica regras do Firebase e não ativa pagamentos ou serviços de e-mail. Esses serviços precisam ser configurados e testados separadamente.
