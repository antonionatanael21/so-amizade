# SÓ AMIZADE — pacote para publicação na Netlify

Este é o **projeto-fonte completo**. Para publicar corretamente a aplicação e a função de validação de idade, a Netlify precisa construir o projeto a partir da raiz do repositório.

## 1. Publicação correta

A raiz do repositório deve conter, no mesmo nível:

- `package.json`
- `netlify.toml`
- `netlify/functions/verify-age.mjs`
- `src/`
- `public/`

No projeto da Netlify, conecte o repositório GitHub e deixe o diretório-base vazio (raiz). O arquivo `netlify.toml` já define:

- Build command: `npm run build`
- Publish directory: `dist`
- Functions directory: `netlify/functions`
- Node.js: `22`

**Não envie apenas `dist/`. Não envie o ZIP como se fosse o diretório publicado do site.** O ZIP deve ser extraído e o conteúdo dele deve ser colocado na raiz do repositório GitHub. A Netlify então faz o build e publica os arquivos estáticos e a função.

## 2. Corrigir o erro `Firebase: Error (auth/unauthorized-domain)`

Esse erro não é corrigido pelo build. O Firebase precisa autorizar o endereço público da aplicação:

1. Abra <https://console.firebase.google.com/>.
2. Selecione o projeto Firebase usado pelo SÓ AMIZADE.
3. Abra **Authentication** → **Settings**.
4. Em **Authorized domains** (Domínios autorizados), clique em **Add domain**.
5. Adicione somente o host do site, por exemplo `meu-site.netlify.app` — sem `https://`, sem caminho e sem barra final.
6. Se a aplicação também usa um domínio personalizado, adicione esse host separadamente.

O domínio exato só é conhecido depois de abrir o site publicado na Netlify. Não adicione um domínio de exemplo: use o endereço real que aparece na barra do navegador.

## 3. Como verificar a função publicada

Depois de concluir o deploy, abra no navegador:

`https://SEU-DOMINIO.netlify.app/.netlify/functions/verify-age`

A resposta esperada é JSON com `ok: true` e o serviço `SÓ AMIZADE age verification`. Se aparecer 404 ou uma página HTML, a função não foi incluída no deploy: confira se `netlify/functions/verify-age.mjs` está na raiz do repositório e se o deploy foi feito a partir do código-fonte completo.

## 4. Limites do que este pacote automatiza

O pacote contém a configuração da Netlify e a função serverless. Ele não consegue, sozinho, entrar nas contas Netlify ou Firebase, criar permissões no projeto, conectar um repositório ou iniciar o deploy. Essas ações exigem autenticação na conta correspondente.

A validação de idade não foi removida nem contornada. O cadastro continua exigindo 18 anos ou mais.
