# SÓ AMIZADE — Rede social para fazer amizades (18+)

Aplicação web responsiva construída com React, TypeScript, Vite, Tailwind CSS e Firebase. O projeto usa Firebase Authentication e Cloud Firestore para login e dados sociais. A hospedagem estática é compatível com Netlify; a verificação de data de nascimento é executada por uma Netlify Function.

> **Importante:** este repositório contém o código da aplicação, mas não prova que os serviços externos já estejam provisionados ou publicados. Antes de abrir o site ao público, conclua as configurações do Firebase e teste os fluxos na URL publicada.

## Estrutura

- `src/`: interface, páginas, contexto de autenticação, serviços e regras auxiliares.
- `netlify/functions/verify-age.mjs`: endpoint serverless usado pelo cadastro e pela etapa de maioridade.
- `netlify.toml`: build, publicação, headers e redirecionamento da função.
- `firebase-applet-config.json`: configuração pública do Firebase usada pelo frontend. A chave web do Firebase não é uma senha de servidor; mantenha as regras do Firestore e do Storage restritivas.
- `firestore.rules` e `storage.rules`: regras que precisam ser publicadas no projeto Firebase.

## Publicar na Netlify

1. Envie esta pasta para um repositório Git e importe-o na Netlify.
2. Use **Build command:** `npm run build`.
3. Use **Publish directory:** `dist`.
4. A configuração de `netlify.toml` já define Node 22 e a pasta `netlify/functions`.
5. Faça o deploy a partir de um repositório Git conectado ou pela Netlify CLI. **Não publique apenas a pasta `dist` por drag-and-drop**, pois isso envia o frontend estático e não inclui `netlify/functions/verify-age.mjs`.
6. Depois do primeiro deploy, adicione o domínio publicado à lista de domínios autorizados do Firebase Authentication.
7. Verifique a função abrindo `https://SEU-SITE.netlify.app/.netlify/functions/verify-age` no navegador. Ela deve responder HTTP 200 com `ok: true`; a rota aceita `POST` para validar a data.

Para testar localmente:

```bash
npm install
npm run dev
```

Para executar os testes automatizados existentes e gerar a versão de produção:

```bash
npm test
npm run build
```

`npm run build` gera somente o frontend estático que a Netlify publica. A Netlify publica as funções da pasta `netlify/functions` separadamente quando o deploy é feito por Git ou CLI. O antigo servidor Express é opcional e não faz parte do deploy estático padrão. Rotas de suporte por e-mail, pagamentos e outras integrações ainda não implementadas respondem como indisponíveis, em vez de fingir que executaram a operação.

**Nota de validação desta entrega:** 40 arquivos TypeScript/TSX passaram pela análise de sintaxe. Os 8 testes utilitários existentes e 5 testes da função de idade passaram (13/13). O build de produção do Vite ainda precisa ser executado após a instalação das dependências; esta entrega não foi publicada na Netlify.

## Configuração necessária no Firebase

No [Firebase Console](https://console.firebase.google.com/), abra o projeto referenciado em `firebase-applet-config.json` e confirme:

1. **Authentication → Sign-in method:** ative E-mail/Senha e Google.
2. **Authentication → Settings → Authorized domains:** adicione o domínio exato do site publicado (por exemplo, `seu-site.netlify.app`) e qualquer domínio próprio que for configurar. Não use curinga.
3. **Authentication → Templates:** revise o nome, o e-mail de suporte e o texto do e-mail de redefinição de senha.
4. **Firestore Database:** confirme que o banco indicado em `firebase-applet-config.json` existe e publique `firestore.rules`.
5. **Storage:** confirme que o bucket do projeto existe e publique `storage.rules`, depois de revisar as permissões para o caso de uso real.

As regras incluídas separam e-mail/data de nascimento do perfil público e restringem gravações sociais a perfis marcados como maiores de idade. A validação da data é executada na interface e em uma Netlify Function, mas **isso ainda não é uma verificação de identidade resistente a adulteração**: como a aplicação web controla o cliente, uma pessoa tecnicamente avançada pode tentar manipular chamadas e dados. Para uma barreira legal/técnica robusta, implemente verificação confiável no backend com Firebase Admin, App Check e controles adequados antes de abrir o serviço ao público.

## Administrador inicial

O código reconhece os endereços abaixo como administradores de bootstrap:

- `tecnomail09@gmail.com` — endereço principal de suporte/admin informado para este projeto.
- `antonionatanael140@gmail.com` — endereço anterior mantido para continuidade.

A promoção depende da autenticação e das regras implantadas. Use um provedor com e-mail verificado; confirme no painel `/admin` depois de fazer login.

## Nome exibido no login do Google

A expressão técnica exibida na janela do Google, por exemplo “Continuar para gen-lang-client-…”, não é controlada pelo texto do React. Atualize a identidade do aplicativo na **Google Cloud Console → Google Auth Platform / Branding** (nome “SÓ AMIZADE”, e-mail de suporte e contatos), revise os domínios autorizados e publique as alterações. O painel administrativo contém atalhos para esses consoles.

O `authDomain` ativo atualmente é `gen-lang-client-0767997957.firebaseapp.com`. O domínio `login.soamizade.com.br` é apenas uma sugestão e **não está configurado por este ZIP**. Para usá-lo, adicione e valide o domínio como domínio personalizado de autenticação no Firebase, configure os DNS conforme as instruções apresentadas pelo próprio Firebase, inclua-o nos domínios autorizados do OAuth e só então defina `VITE_FIREBASE_CUSTOM_AUTH_DOMAIN` nas variáveis da Netlify.

## Recursos que ainda exigem serviços externos

- **Recuperação de senha:** usa o fluxo nativo de redefinição do Firebase Authentication. Personalize e teste o modelo de e-mail no Console.
- **Suporte:** o site abre um rascunho `mailto:` para `tecnomail09@gmail.com`. O usuário precisa confirmar o envio no próprio aplicativo de e-mail. Não há envio automático nem histórico persistente de chamados.
- **Exclusão integral de conta:** o botão prepara uma solicitação por e-mail. A exclusão automática e completa ainda exige uma função de backend com Firebase Admin para remover Authentication, documentos, subcoleções, arquivos e dados relacionados. O botão não apaga parcialmente a conta.
- **Mercado Pago / SÓ AMIZADE+:** checkout fica desativado. Antes de cobrar, implemente autenticação Firebase no servidor, preços definidos no servidor, validação de assinatura do webhook e atualização idempotente do plano após confirmação do provedor. Não habilite pagamentos só por adicionar um Access Token.
- **E-mails automáticos de boas-vindas e suporte:** exigem provedor transacional e uma função segura de servidor; não estão habilitados nesta versão.

## LGPD e dados

O botão de exportação gera um JSON com os dados de perfil e os campos de identidade acessíveis ao próprio usuário. A data de nascimento e o e-mail são armazenados em `users/{uid}/private/identity`, separados do documento público. Solicitações de exclusão integral são encaminhadas ao suporte até existir um processo automatizado e auditável.

Antes do lançamento, publique uma Política de Privacidade e Termos com informações reais sobre controlador, finalidade, base legal, retenção, contato, direitos dos titulares e provedores utilizados. O conteúdo jurídico do site deve ser revisado para refletir exatamente os serviços efetivamente ativados.
